//OSCELTON.js
//A javscript implimentation for using data from OSCeleton in Max for Live

//our defualts
autowatch = 1;
inlets = 1;
outlets = 2;

//clears the lcd window
outlet(1,"clear");
//a joint object, to hold the information from OSCeleton for each recorded joint
var joint = function(x,y,z){
    this.x = 0.5;
    this.y = 0.5;
    this.z = 0.5;
    return this;
}
//extend the joint object to update the encapsulated info
joint.prototype.update = function(thisx,thisy,thisz) {
    this.x = thisx;
    this.y = thisy;
    this.z = thisz;
}
//return the joint as a formatted string
joint.prototype.print = function() {
    return(this.x +" " +  this.y + " "+ " " + this.z + "");
}
//array to hold each user from OSCeleton (up to 4)
var userArray = new Array();
//user object to hold position and joints array data
var user = function(x,y,z) {
    this.joints = new Array();
    this.position = new joint(x,y,z);
    return this;
}
//prints the Joint information for given user index to the Max window
function printUser(index) {
    post("User #" + index + " at position -" + userArray[index].position.print());
    post("\n");
    for (objName in userArray[index].joints) {
        post(objName + ": ");
        post(userArray[index].joints[objName].print());
        post("\n");
    }
}
//draws a circle for each joint of each user in lcd by outputting commands through
//outlet 1.
function drawUser(index) {
    outlet(1,"clear");
    if (userArray[index].hasOwnProperty('joints')) {
        for (objName in userArray[index].joints) {
            outlet(1,"frameoval",Number(userArray[index].joints[objName].x * 170),Number(userArray[index].joints[objName].y * 170),Number(userArray[index].joints[objName].x * 170) + 10,Number(userArray[index].joints[objName].y * 170) + 10);
        }        
    }
}
//bang function - when called, calls drawUser on each user in userArray
function bang() {
    if (userArray.length) {
	    for (objName in userArray) {
		    drawUser(objName);
	    }
    }
}
//handles messages passed to this JS object
function anything() {
    if (arguments.length) {
        var messageArgs = arrayfromargs(arguments);
	//split the incoming osc message at the "/" character
        tempArray = messagename.split("/");
	//tempArray[0] is a blank space, so therefore we check tempArray[1]
	//for the JS function to call
        if (tempArray[1] === "new_user") {
	    //a new user is recognized in OSCeleton
	    userArray[tempArray[2]] = new user(messageArgs[0],messageArgs[1], messageArgs[2]);
        }
        else if (tempArray[1] === "user") {
	    //user is found, but no skeleton data yet
	    //format of message is: /user/1 positionx positiony posotionz
	    if (!userArray[tempArray[2]]) {
                userArray[tempArray[2]] = new user(messageArgs[0],messageArgs[1], messageArgs[2]);
            }
            else userArray[tempArray[2]]["position"].update(messageArgs[0],messageArgs[1], messageArgs[2]);
        }
        else if (tempArray[1] === "new_skel") {
	    //new skeleton is recognized    
        }
        else if (tempArray[1] === "joint") {
	    //joint information in postitionx positiony positionz format
            if (!userArray[messageArgs[1]]) {
		//check for user in userArray, if no user, make one.
            	userArray[messageArgs[1]] = new user(.5,.5,.45);
            }
            if (!userArray[messageArgs[1]].joints[messageArgs[0]]) {
		//check for joint name in joints array, if none, make a new one
            	userArray[messageArgs[1]].joints[messageArgs[0]] = new joint(messageArgs[2],messageArgs[3],messageArgs[4]);   
            }
		//otherwise update the joint info
            else userArray[messageArgs[1]].joints[messageArgs[0]].update(messageArgs[2],messageArgs[3],messageArgs[4]);

	    //if the joint calling this message is the right or left hand
	    if (messageArgs[0] === "r_hand" || messageArgs[0] === "l_hand") {
		if (messageArgs[4] < .675) {
		    //can do things when zposition is SUPER close
		}
		if (messageArgs[4] < 1.0) {
		    //outputs whenever the z value is greater than .675 but less than 1
		    outlet(0,messageArgs[0],(1-messageArgs[4])*2);
		}	    
	    }
	}  
    }
}


